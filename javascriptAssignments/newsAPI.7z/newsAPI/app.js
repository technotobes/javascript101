const newsUL = document.getElementById("newsUL");
const sourceUL = document.getElementById("sourceUL");
const sourceSelect = document.getElementById("sourceSelect");

let articles = news.articles;
let sourceItems = sources.sources;

displayNews(articles);

const idArticleItems = articles.map(function (article) {
  let articleID = article.source.id;
  idArr = [];
  let filteredID = sourceItems.filter(function (source) {
    console.log(source.id);
  });
  // console.log(articleID);
});

// const idItemSources = sourceItems.map(function (source) {
//   const filteredID = articles.map(function (article) {
//     if ()
//       return `<option>${article.source.name}</option>`;
//     }
//   });
//   console.log(idItemNews);
//   sourceSelect.innerHTML = idItemNews;
// });

// sourceSelect.addEventListener("change", function () {
//   const selectedSource = this.value;

//   if (selectedSource == "- View All -") {
//     displaySources(sourceItems);
//   } else {
//     const filteredSources = sourceItems.filter(function (source) {
//       if (source.id == filteredSources) {
//         return `<option>${filteredSources}</option>`;
//       }
//     });
//     console.log(filteredSources);
//     displaySources(filteredSources);
//   }
// });

function displaySources(sourcesToDisplay) {
  const sourceItem = sourcesToDisplay.map(function (source) {
    return `<li>
    <b>${source.name}</b>
    <p>${source.description}</p>
    <a href="${source.url}">${source.url}</a><br />
  </li><br />`;
  });

  sourceUL.innerHTML = sourceItem.join("");
}

function displayNews(newsToDisplay) {
  const newsItem = newsToDisplay.map((article) => {
    return `<li>
      <h2>${article.title}<h2>
      <h3>${article.author}</h3>
      <p>${article.description}<p>
      <a href="${article.url}">${article.url}<a><br />
      <img src="${article.urlToImage}" />
      <p>${article.publishedAt}</p>
      </li>`;
  });

  newsUL.innerHTML = newsItem.join("");
}
